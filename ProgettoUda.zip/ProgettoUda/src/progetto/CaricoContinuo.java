package progetto;

public class CaricoContinuo extends Elettrodomestici{

    private int consumoAnno ;
    private double consumoOra;

    public CaricoContinuo(String nome, int consumoAnno) {
        super(nome);
        this.consumoAnno = consumoAnno;
        this.consumoOra = consumoAnno/(365*24);

    }

    public int getConsumoAnno() {
        return consumoAnno;
    }

    public void setConsumoAnno(int consumoAnno) {
        this.consumoAnno = consumoAnno;
    }

    public double getConsumoOra() { return consumoOra;}
    @Override
    public double calcolaConsumo(double tempoH){

        return tempoH*consumoOra;
    }
}
