package progetto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Fotovoltaico {
    // in questa classe calcoliamo la produzione in base a ora, stagione e condizione meteo
    private double potenzaMax=0;
    private Map<String, List<Double>> mappaPercentuali = new HashMap<>();

    public Fotovoltaico() {
        inizializzaMappe();
        caricaDati();
    }


    private void inizializzaMappe() {
        mappaPercentuali.put("primavera", new ArrayList<>());
        mappaPercentuali.put("estate", new ArrayList<>());
        mappaPercentuali.put("autunno", new ArrayList<>());
        mappaPercentuali.put("inverno", new ArrayList<>());
    }

    private void caricaDati() {
        // la hash map ha come indici le ore del giorno
        double[] primavera = {0,0,0,0,0,0,0, 0.10, 0.25, 0.45, 0.65, 0.80, 0.85, 0.82, 0.70, 0.50, 0.30, 0.10, 0,0,0,0,0,0};
        double[] estate    = {0,0,0,0,0,0,0, 0.15, 0.35, 0.55, 0.75, 0.90, 0.95, 0.92, 0.80, 0.65, 0.45, 0.20, 0,0,0,0,0,0};
        double[] autunno   = {0,0,0,0,0,0,0, 0.05, 0.15, 0.35, 0.50, 0.65, 0.70, 0.68, 0.55, 0.35, 0.15, 0.05, 0,0,0,0,0,0};
        double[] inverno   = {0,0,0,0,0,0,0, 0.00, 0.10, 0.25, 0.40, 0.55, 0.60, 0.58, 0.45, 0.25, 0.05, 0.00, 0,0,0,0,0,0};

        for (int i = 0; i < 24; i++) {
            mappaPercentuali.get("primavera").add(primavera[i]);
            mappaPercentuali.get("estate").add(estate[i]);
            mappaPercentuali.get("autunno").add(autunno[i]);
            mappaPercentuali.get("inverno").add(inverno[i]);
        }
    }
    public double calcolaProduzione(int ora, int condizioniMeteo, String stagione) {
        if (ora < 0 || ora > 23) return 0;

        double potenzaBaseMeteo = potenzaMeteo(condizioniMeteo);
        double percentualeProduzione = mappaPercentuali.get(stagione).get(ora);

        return potenzaBaseMeteo * percentualeProduzione;
    }

    private double potenzaMeteo(int condizioniMeteo) {
        switch (condizioniMeteo) {
            case 1: return potenzaMax;       // Sole
            case 2: return potenzaMax * 0.4; // Nuvoloso
            case 3: return potenzaMax * 0.15;// Pioggia
            default: return 0;
        }
    }


    public double getPotenzaMax() { return potenzaMax; }
    public void setPotenzaMax(double potenzaMax) { this.potenzaMax = potenzaMax; }
}