package progetto;
import java.util.Scanner;

public class CaricoCiclico extends Elettrodomestici{
    // elettrodomestici che si caricano e hanno una durata prestabilita
    private double minimo;
    private double medio;
    private double massimo;

    public CaricoCiclico(String nome, double minimo, double medio, double massimo) {
        super(nome);
        this.minimo=minimo;
        this.massimo=massimo;
        this.medio=medio;
    }

    public double getMinimo() {
        return minimo;
    }

    public void setMinimo(int minimo) {
        this.minimo = minimo;
    }

    public double getMedio() {
        return medio;
    }

    public void setMedio(int medio) {
        this.medio = medio;
    }

    public double getMassimo() {
        return massimo;
    }

    public void setMassimo(int massimo) {
        this.massimo = massimo;
    }
    public int calcoloSurplus(int produzione,int consumoElettrodomestico ){
        int Surplus= produzione-consumoElettrodomestico;
        return Surplus;
    }
@Override
    public double calcolaConsumo(double tempoH) { //il nostro tempoH è il livello di potenza
    double consumo=0;
    int potenza = (int)tempoH;
    switch (potenza){
           case 1:
               consumo=minimo;
                break;

            case 2:
                consumo=medio;
                break;

            case 3:
                consumo = massimo;
                break;

            default:break;


    }
        return consumo;
    }
}
