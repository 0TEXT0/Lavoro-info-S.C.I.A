package progetto;

public class CaricoManuale extends Elettrodomestici{
    private double potenza;

    public CaricoManuale(String nome, double potenza) {
        super(nome);
        this.potenza = potenza;
    }

    public double getPotenza() {
        return potenza;
    }

    public void setPotenza(double potenza) {
        this.potenza = potenza;
    }

@Override
    public double calcolaConsumo (double tempoH){
        return potenza * tempoH;
    }

}
