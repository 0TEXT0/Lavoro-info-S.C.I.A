package progetto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DatabaseElettrodomestici {
    private Map<String, String> elenco = new HashMap<>();
    private int nElettrodomestici = 8;
    private ArrayList<Elettrodomestici> elencoAggiunti;

    public DatabaseElettrodomestici() {
        caricaElettrodomestici();
        elencoAggiunti = new ArrayList<>();
    }

    private void caricaElettrodomestici() {
        elenco.put("lavatrice", "Ciclico");
        elenco.put("phon", "Manuale");
        elenco.put("frigorifero", "Continuo");
        elenco.put("friggitrice ad aria", "Manuale");
        elenco.put("lavastoviglie", "Ciclico");
        elenco.put("condizionatore", "Manuale");
        elenco.put("aspirapolvere", "manuale");
        elenco.put("forno", "Ciclico");
    }

    public String stampaElettrodomestici() {
        String stampa = "elenco =";
        for (String chiave : elenco.keySet()) {
            stampa = stampa + ", " + chiave;
        }
        return stampa;
    }

    public Elettrodomestici cerca(String nomeElettrodomestico) {
        String nomeLower = nomeElettrodomestico.toLowerCase();

        if (!elenco.containsKey(nomeLower)) {
            System.out.println("Errore: Elettrodomestico non trovato nel database.");
            return null;
        }

        String categoria = elenco.get(nomeLower);
        return caricaDatiSpecifici(nomeLower, categoria);
    }

    private Elettrodomestici caricaDatiSpecifici(String nome, String categoria) {
        String nomeFile = "carico_" + categoria + ".csv";

        try (BufferedReader br = new BufferedReader(new FileReader(nomeFile))) {
            String riga;
            br.readLine(); // Salto l'intestazione del file CSV

            while ((riga = br.readLine()) != null) {
                String[] dati = riga.split(",");

                if (dati[0].equalsIgnoreCase(nome)) {

                    // Istanzio la classe corretta in base alla categoria
                    switch (categoria.toLowerCase()) {
                        case "ciclico":
                            // dati[1]=min, dati[2]=medio, dati[3]=max
                            return new CaricoCiclico(dati[0],
                                    Double.parseDouble(dati[1]),
                                    Double.parseDouble(dati[2]),
                                    Double.parseDouble(dati[3]));

                        case "manuale":
                            // dati[1]=potenza nominale
                            return new CaricoManuale(dati[0],
                                    Double.parseDouble(dati[1]));

                        case "continuo":
                            // dati[1]=consumo anno
                            return new CaricoContinuo(dati[0],
                                    Integer.parseInt(dati[1]));
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Errore di lettura nel file: " + nomeFile);
        } catch (NumberFormatException e) {
            System.err.println("Errore nel formato dei dati numerici nel file CSV.");
        }

        return null;
    }
    public void aggiungiElettrodomestici(Elettrodomestici nuovo){
        this.elencoAggiunti.add(nuovo);

    }
    public void rimuoviElettrodomestici (Elettrodomestici daEliminare){
        this.elencoAggiunti.remove(daEliminare);
    }

    public ArrayList <Elettrodomestici> getElettrodomestici() {
        return this.elencoAggiunti;
    }
}