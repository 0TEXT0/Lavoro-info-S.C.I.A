package progetto;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        DatabaseElettrodomestici catalogo = new DatabaseElettrodomestici();
        Fotovoltaico fotovoltaico = new Fotovoltaico();
        Scanner tastiera = new Scanner(System.in);

        System.out.println("Buongiorno e benvenuti.");
        System.out.println("Inserire la potenza del proprio impianto fotovoltaico (kW):");
        do {
            fotovoltaico.setPotenzaMax(tastiera.nextDouble());
        } while (fotovoltaico.getPotenzaMax() == 0);

        int scelta;
        do {
            scelta = menu(tastiera);
            gestioneProgramma(scelta, tastiera, catalogo, fotovoltaico);
        } while (scelta != 0);
    }


    public static int menu(Scanner tastiera) {
        int scelta;
        System.out.println("\nSelezionare l'operazione desiderata:");
        System.out.println("0. Exit");
        System.out.println("1. Inserire un nuovo elettrodomestico nel calcolo");
        System.out.println("2. Eliminare un elettrodomestico dal calcolo");
        System.out.println("3. Calcolare lo stato energetico della casa");
        do {
            scelta = tastiera.nextInt();
        } while (scelta < 0 || scelta > 3);
        return scelta;
    }

    public static void gestioneProgramma(int scelta, Scanner tastiera, DatabaseElettrodomestici catalogo, Fotovoltaico fotovoltaico) {
        switch (scelta) {

            case 0:
                // Uscita dal programma
                System.out.println("Uscita dal programma. Arrivederci!");
                break;

            case 1:
                // Inserire un nuovo elettrodomestico nel calcolo
                System.out.println("Inserire il nome dell'elettrodomestico da aggiungere:");
                tastiera.nextLine();
                String nomeNuovo = tastiera.nextLine().toLowerCase();

                Elettrodomestici daAggiungere = catalogo.cerca(nomeNuovo);
                if (daAggiungere != null) {
                    catalogo.aggiungiElettrodomestici(daAggiungere);
                    System.out.println("Elettrodomestico \"" + nomeNuovo + "\" aggiunto con successo.");
                } else {
                    System.out.println("Elettrodomestico non trovato nel database.");
                }
                break;

            case 2:
                // Eliminare un elettrodomestico dal calcolo
                System.out.println("Inserire il nome dell'elettrodomestico da rimuovere:");
                tastiera.nextLine();
                String nomeRimozione = tastiera.nextLine().toLowerCase();

                Elettrodomestici daRimuovere = catalogo.cerca(nomeRimozione);
                if (daRimuovere != null) {
                    catalogo.rimuoviElettrodomestici(daRimuovere);
                    System.out.println("Elettrodomestico \"" + nomeRimozione + "\" rimosso con successo.");
                } else {
                    System.out.println("Elettrodomestico non trovato nel database.");
                }
                break;

            case 3:
                /* Calcolare lo stato energetico della casa in base alla produzione dei pannelli (data da ora, stagione e
                 *meteo) e al consumo attuale
                 */
                ArrayList<Elettrodomestici> elencoAggiunti = catalogo.getElettrodomestici();

                System.out.println("Inserire l'ora attuale (0-23):");
                int ora = tastiera.nextInt();

                System.out.println("Inserire la stagione (Primavera / Estate / Autunno / Inverno):");
                tastiera.nextLine();
                String stagione;
                do {
                    stagione = tastiera.nextLine();
                } while (!stagione.equalsIgnoreCase("estate") &&
                        !stagione.equalsIgnoreCase("autunno") &&
                        !stagione.equalsIgnoreCase("inverno") &&
                        !stagione.equalsIgnoreCase("primavera"));


                System.out.println("Inserire le condizioni meteo:");
                System.out.println("  1 = Sole  |  2 = Nuvoloso  |  3 = Pioggia");
                int meteo;
                do {
                    meteo = tastiera.nextInt();
                } while (meteo < 1 || meteo > 3);

                double produzione = fotovoltaico.calcolaProduzione(ora, meteo, stagione);
                System.out.printf("Produzione solare attuale: %.2f kW%n", produzione);

                double consumoOra = 0;
                double consumoTotale = 0;
                if (elencoAggiunti.isEmpty()) {
                    System.out.println("Non è acceso alcun elettrodomestico");
                } else {


                    for (Elettrodomestici e : elencoAggiunti) {
                        if (e instanceof CaricoCiclico) { //comando rapido in Java per verificare l'apartenenza di un oggetto ad una classe
                            System.out.println("Inserire il livello di potenza (1 | 2 | 3) per : " + e.getNome());
                            int tempo = tastiera.nextInt();
                            consumoTotale += e.calcolaConsumo((double) tempo);
                        } else {
                            System.out.println("Inserire tempo di utilizzo (ore) per: " + e.getNome());
                            double tempo = tastiera.nextDouble();
                            consumoTotale += e.calcolaConsumo(tempo);
                        }
                    }
                }
                double surplus = calcoloSurplus(produzione, consumoTotale);

                if (surplus > 0) {
                    System.out.printf("Surplus energetico: +%.2f kW — stai producendo più di quanto consumi.%n", surplus);
                    System.out.println("Si consiglia di avviare il ciclo di un elettrodomestico a carico ciclico per dimimnuire gli scprechi di energia");
                } else if (surplus < 0) {
                    System.out.printf("Deficit energetico: %.2f kW — stai consumando più di quanto produci.%n", surplus);
                } else {
                    System.out.println("Bilancio energetico in pareggio.");
                }


                break;

            default:
                System.out.println("Scelta non valida.");
                break;
        }
    }
    public static double calcoloSurplus(double produzione, double consumo) {
        return produzione - consumo;
    }
}