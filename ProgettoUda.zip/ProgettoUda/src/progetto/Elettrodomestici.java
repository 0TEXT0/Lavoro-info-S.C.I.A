package progetto;

import java.util.ArrayList;

public abstract class Elettrodomestici {
    private String nome;

    public Elettrodomestici(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void surplusEccessivo(int Surplus){
        if(Surplus >= 3000){
            System.out.println("Ti consiglio di accendere la lavatrice perchè il tuo surplus energetico  ");
        }
    }

    public abstract double calcolaConsumo(double tempoH);


}
